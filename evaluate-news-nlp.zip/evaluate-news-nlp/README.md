## project with the webpack library 
the webpack help us to make all assets in small files 
## how to use :
you can put the url of an news article in the url place holder and press submit and see what was happened