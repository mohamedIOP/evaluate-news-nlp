function handleSubmit(event) {
    event.preventDefault()

    // check what text was put into the form field
    let formText = document.getElementById('name').value
    if(Client.checkForName(formText)){
    const getNewData = async (link)=>{
        const infoApi = await fetch(link);
        try{
            const finalData = await infoApi.json();
            console.log(finalData);
            var textMessage = '';
            const reducer = ()=> {;for(let x = 0 ;x < finalData.sentence_list.length;x++){
                let text = '';
                text = finalData.sentence_list[x].text;
                textMessage = textMessage + text;
            }};
            reducer();
            document.getElementById('results').innerHTML = 
            `agreement:${finalData.agreement},<br>
            confidence:${finalData.confidence},<br>
            irony:${finalData.irony},<br>
            model:${finalData.model},<br>
            score_tag:${finalData.score_tag},<br>
            text:${textMessage}`;
            return finalData
        }catch(error){
            console.log('error',error);
        }
    }
    fetch('http://localhost:8081/test')
    .then(res => res.json())
    .then(function(res) {
        res.url = formText;
        const link = `https://api.meaningcloud.com/sentiment-2.1?key=${res.application_key}&of=json&url=${res.url}&lang=${res.lang}`;
        console.log(link);
        getNewData(link);
    })}
    else if(!formText == ''){
        alert('the url you entered is not validate');
        document.getElementById('results').innerHTML = '';
    }
    else{
        alert('the input is empty')
        document.getElementById('results').innerHTML = '';
    }
}

export { handleSubmit }
